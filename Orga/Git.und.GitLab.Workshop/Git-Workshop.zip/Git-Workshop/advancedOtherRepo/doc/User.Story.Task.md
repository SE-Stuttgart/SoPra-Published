# Titel/Name

Tasks sind einzelne Aufgaben, die notwendig sind, um eine Implementable Story fertig zu stellen. Ein Task hat im Allgemeinen einen Umfang von bis zu mehreren Stunden.

> Als *Rolle* möchte ich *Ziel/Wunsch*, um *Nutzen*.

- Aufwandsschätzung: [0-24] Stunden
- Tatsächliche Zeit: [0-72] Stunden

___

# Beispiel-Task: Vorlesung nachbereiten

Als Bachelor-Student möchte ich die besuchte Vorlesung nachbereiten, um den Stoff besser zu verinnerlichen.

- Aufwandsschätzung: 3 Stunden
- Tatsächliche Zeit: 5 Stunden