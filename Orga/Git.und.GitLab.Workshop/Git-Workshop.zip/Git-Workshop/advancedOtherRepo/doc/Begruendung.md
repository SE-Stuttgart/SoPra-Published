# Begründungen

In diesem Dokument werden die Begründungen für **nicht bearbeitete oder ignorierte Hauptbefunde und kritische Befunde** aufgelistet:

## Begründung 1 (Befund X)

Den Befund X haben wir ignoriert, weil *TODO*.

## Begründung 2 (Befund Y)

Den Befund Y haben nicht bearbeitet, weil *TODO*.