# Titel/Name

Beschreibung der Anforderung auf höchster Abstraktionsebene. Epic User Stories beschreiben Anforderungen die im Allgemeinen einen Umfang von mehreren Monaten haben.

> Als *Rolle* möchte ich *Ziel/Wunsch*, um *Nutzen*.

## Enthaltene Features

- [Feature 1](User.Story.Feature.1.md)
- [Feature 2](User.Story.Feature.2.md)
- [Feature 3](User.Story.Feature.3.md)

___

# Beispiel-Epic: Bachelor-Abschluss Softwaretechnik

Als engagierter Student möchte ich meinen Bachelor-Abschluss in Softwaretechnik in Regelstudienzeit abschließen.

## Enthaltene Features

- Mathematik bestehen
- SoPra bestehen
- Theoretische Informatik bestehen
- ...