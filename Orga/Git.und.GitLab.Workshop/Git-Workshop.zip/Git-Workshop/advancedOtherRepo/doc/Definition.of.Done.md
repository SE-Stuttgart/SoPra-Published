# Definition of Done

- Alle zur User Story assoziierten Test sind erfolgreich durchgelaufen.
- Die Testabdeckung beträgt mindestens 75 %.
- Der Entwurf wurde aktualisiert.
- Der Code ist kommentiert.
- **TODO zusätzliches Kriterium 1**
- **TODO zusätzliches Kriterium 2**
- **TODO zusätzliches Kriterium 3**
